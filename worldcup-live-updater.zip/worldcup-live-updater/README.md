# Football Fun Live Updater v4.1

Pouzdani višestruki izvor za Football Fun.

## HNL v5.19.1

- Primarni izvor: službeni HNS Semafor za SuperSport HNL 2026/27.
- Rezervni izvor: službeni hnl.hr.
- Dohvaća puni raspored, rezultate i tablicu.
- Ne izmišlja vrijeme početka kada službeni izvor objavi samo datum.
- Čuva zadnju provjerenu HNL kopiju ako službena stranica privremeno ne odgovara.
- U `live-results.json` zapisuje dijagnostiku: status, broj HNL utakmica, broj klubova tablice i vrijeme zadnjeg uspješnog osvježavanja.

## Postavljanje

U postojećem repozitoriju `worldcup-live-updater` zamijeni `update.py` i `requirements.txt`, napravi commit i ručno jednom pokreni postojeći workflow.
