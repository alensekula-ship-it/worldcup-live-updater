# Football Fun live updater v2

This updater keeps the API token inside the existing GitHub secret named `API_TOKEN`.
It publishes public match data to `live-results.json` without exposing the token.

Changes:
- refresh every 5 minutes
- complete World Cup match list
- nearby matches from all football-data.org competitions in the package
- full details for live, just-finished and imminent matches
- goals, cards, substitutions, statistics, lineups, bench, attendance and referee when supplied by the API

Upload these files over the existing files in the `worldcup-live-updater` repository and run the workflow manually once.
