# Football Fun live updater v3

Updates `live-results.json` from football-data.org.

## Included

- Matches from all competitions available in the connected plan
- Live match details when available
- Real competition standings
- Rate-limit-safe standings rotation: two stale competitions per run
- Existing verified standings remain available if one API request fails

The existing GitHub Actions workflow and `API_TOKEN` secret can remain unchanged.
After installing this version, run the workflow several times or allow scheduled runs to populate all available standings.
