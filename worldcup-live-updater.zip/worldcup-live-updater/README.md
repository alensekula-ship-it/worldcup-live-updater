# Football Fun live updater v4 — official HNL connection

Updates `live-results.json` from two verified public sources:

- `football-data.org` for the competitions available in the connected account
- the official SuperSport HNL / HNS pages for HNL fixtures, results and standings

## HNL safety rules

- Existing verified HNL data is kept if the official page is unavailable.
- A new HNL table is accepted only when all 10 clubs are parsed.
- A new HNL schedule is accepted only when at least 10 matches are parsed.
- No demo scores or invented standings are generated.

Replace `update.py` and `requirements.txt` in the existing updater repository. The current GitHub Actions workflow and `API_TOKEN` secret can remain unchanged.
