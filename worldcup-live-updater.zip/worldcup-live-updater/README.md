# worldcup-live-updater

Automatic football-data.org updater for World Cup Fan 2026 live data.

Required GitHub secret:

- `API_TOKEN` = football-data.org API token

Output file:

- `live-results.json`
