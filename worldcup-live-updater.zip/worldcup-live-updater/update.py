import json
import os
from datetime import datetime, timezone

import requests

API_TOKEN = os.getenv("API_TOKEN")
if not API_TOKEN:
    raise RuntimeError("Missing API_TOKEN GitHub secret")

URL = "https://api.football-data.org/v4/competitions/WC/matches?season=2026"
HEADERS = {"X-Auth-Token": API_TOKEN}


def norm_group(group):
    if not group:
        return ""
    group = str(group)
    if group.startswith("GROUP_"):
        return group.replace("GROUP_", "")
    return group.replace("Group ", "")


def score_value(match, side):
    # side: home or away
    score = match.get("score") or {}
    for bucket in ("fullTime", "regularTime", "halfTime"):
        obj = score.get(bucket) or {}
        val = obj.get(side)
        if val is not None:
            return val
    return None


def one_match(match):
    home = match.get("homeTeam") or {}
    away = match.get("awayTeam") or {}
    utc_date = match.get("utcDate") or ""
    date_text = utc_date.replace("T", " ").replace("Z", "")[:16]
    item = {
        "id": match.get("id"),
        "date": date_text,
        "status": match.get("status", ""),
        "group": norm_group(match.get("group") or match.get("stage")),
        "home": home.get("name") or home.get("shortName") or home.get("tla") or "",
        "away": away.get("name") or away.get("shortName") or away.get("tla") or "",
        "homeTla": home.get("tla", ""),
        "awayTla": away.get("tla", ""),
        "stage": match.get("stage", ""),
        "matchday": match.get("matchday"),
        "lastUpdated": match.get("lastUpdated", ""),
    }
    hg = score_value(match, "home")
    ag = score_value(match, "away")
    if hg is not None and ag is not None:
        item["homeGoals"] = hg
        item["awayGoals"] = ag
    return item


def main():
    response = requests.get(URL, headers=HEADERS, timeout=20)
    print(response.status_code)
    response.raise_for_status()
    raw = response.json()
    matches = [one_match(m) for m in raw.get("matches", [])]

    live_statuses = {"IN_PLAY", "PAUSED", "LIVE"}
    finished_statuses = {"FINISHED"}
    upcoming_statuses = {"TIMED", "SCHEDULED"}

    live = [m for m in matches if m.get("status") in live_statuses]
    finished = [m for m in matches if m.get("status") in finished_statuses]
    upcoming = [m for m in matches if m.get("status") in upcoming_statuses]

    data = {
        "lastUpdate": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "source": "football-data.org",
        "competition": raw.get("competition", {}).get("name", "FIFA World Cup"),
        "season": raw.get("filters", {}).get("season", "2026"),
        "liveCount": len(live),
        "finishedCount": len(finished),
        "upcomingCount": len(upcoming),
        "matches": matches,
        "live": live,
        "finished": finished,
        "upcoming": upcoming,
        "goldenBoot": [],
        "mvp": [],
    }

    with open("live-results.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print(f"live-results.json updated: {len(live)} live, {len(finished)} finished, {len(upcoming)} upcoming, {len(matches)} total")


if __name__ == "__main__":
    main()
