import copy
import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

API_TOKEN = os.getenv("API_TOKEN")
if not API_TOKEN:
    raise RuntimeError("API_TOKEN is missing")

BASE_URL = "https://api.football-data.org/v4"
HEADERS = {"X-Auth-Token": API_TOKEN}
OUTPUT_FILE = Path("live-results.json")

# Competitions available in the user's football-data.org package.
CLUB_CODES = ["CL", "BL1", "DED", "BSA", "PD", "FL1", "ELC", "PPL", "SA", "PL"]
NATIONAL_CODES = ["WC", "EC"]
ALL_CODES = NATIONAL_CODES + CLUB_CODES
LIVE_STATUSES = {"LIVE", "IN_PLAY", "PAUSED", "EXTRA_TIME", "PENALTY_SHOOTOUT"}
FINISHED_STATUSES = {"FINISHED", "AWARDED"}
UPCOMING_STATUSES = {"TIMED", "SCHEDULED"}


def api_get(path: str, params: dict | None = None) -> dict:
    response = requests.get(f"{BASE_URL}{path}", headers=HEADERS, params=params, timeout=35)
    if response.status_code != 200:
        raise RuntimeError(f"football-data.org error {response.status_code}: {response.text[:500]}")
    return response.json()


def merge_matches(*collections: list[dict]) -> list[dict]:
    by_id: dict[int | str, dict] = {}
    for collection in collections:
        for match in collection or []:
            key = match.get("id") or f"{match.get('utcDate')}:{match.get('homeTeam', {}).get('name')}:{match.get('awayTeam', {}).get('name')}"
            by_id[key] = match
    return sorted(by_id.values(), key=lambda m: m.get("utcDate") or "")


def should_fetch_details(match: dict, now: datetime) -> bool:
    status = str(match.get("status") or "").upper()
    if status in LIVE_STATUSES:
        return True

    utc_date = match.get("utcDate")
    if not utc_date:
        return False
    try:
        kickoff = datetime.fromisoformat(utc_date.replace("Z", "+00:00"))
    except ValueError:
        return False

    if status in FINISHED_STATUSES and kickoff.date() == now.date():
        return True
    if status in UPCOMING_STATUSES and timedelta(hours=-1) <= kickoff - now <= timedelta(hours=4):
        return True
    return False


def enrich_with_match_details(matches: list[dict], now: datetime) -> list[dict]:
    enriched: list[dict] = []
    detailed_requests = 0

    for match in matches:
        item = match
        match_id = match.get("id")
        if match_id and should_fetch_details(match, now) and detailed_requests < 5:
            try:
                # Full Match Resource contains lineups, bench, goals, bookings,
                # substitutions, team statistics, attendance and referees when available.
                item = api_get(f"/matches/{match_id}")
                detailed_requests += 1
                time.sleep(1.2)
            except Exception as exc:
                print(f"Detail fetch failed for match {match_id}: {exc}")
        enriched.append(item)

    print(f"Detailed match requests: {detailed_requests}")
    return enriched


def without_timestamps(payload: dict) -> dict:
    cleaned = copy.deepcopy(payload)
    cleaned.pop("generatedAt", None)
    cleaned.pop("lastUpdate", None)
    return cleaned


def load_existing() -> dict | None:
    if not OUTPUT_FILE.exists():
        return None
    try:
        return json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def main() -> None:
    now = datetime.now(timezone.utc)

    # Preserve the complete World Cup list so group tables and knockout history
    # remain available throughout the tournament.
    world_cup = api_get("/competitions/WC/matches").get("matches", [])

    # Other supported competitions are kept focused around the current period.
    date_from = (now - timedelta(days=14)).date().isoformat()
    date_to = (now + timedelta(days=60)).date().isoformat()
    other_codes = ",".join(code for code in ALL_CODES if code != "WC")
    nearby = api_get(
        "/matches",
        params={"competitions": other_codes, "dateFrom": date_from, "dateTo": date_to},
    ).get("matches", [])

    matches = merge_matches(world_cup, nearby)
    matches = enrich_with_match_details(matches, now)

    output = {
        "source": "football-data.org",
        "generatedAt": now.strftime("%Y-%m-%d %H:%M UTC"),
        "lastUpdate": now.strftime("%Y-%m-%d %H:%M UTC"),
        "competitionCodes": ALL_CODES,
        "matches": matches,
        "live": [],
        "finished": [],
        "upcoming": [],
    }

    for match in matches:
        status = str(match.get("status") or "").upper()
        if status in LIVE_STATUSES:
            output["live"].append(match)
        elif status in FINISHED_STATUSES:
            output["finished"].append(match)
        elif status in UPCOMING_STATUSES:
            output["upcoming"].append(match)

    existing = load_existing()
    if existing is not None and without_timestamps(existing) == without_timestamps(output):
        print("No football data changes; live-results.json left unchanged")
        return

    OUTPUT_FILE.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print("live-results.json updated")
    print("Matches:", len(matches))
    print("Live:", len(output["live"]))
    print("Finished:", len(output["finished"]))
    print("Upcoming:", len(output["upcoming"]))


if __name__ == "__main__":
    main()
