import copy
import html as html_lib
import json
import os
import re
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

API_TOKEN = os.getenv("API_TOKEN")
if not API_TOKEN:
    raise RuntimeError("API_TOKEN is missing")

BASE_URL = "https://api.football-data.org/v4"
HEADERS = {"X-Auth-Token": API_TOKEN}
PUBLIC_HEADERS = {
    "User-Agent": "FootballFunDataUpdater/5.19 (+https://github.com/alensekula-ship-it/worldcup-live-updater)",
    "Accept-Language": "hr-HR,hr;q=0.9,en;q=0.7",
}
OUTPUT_FILE = Path("live-results.json")

# Competitions available in the user's football-data.org package.
CLUB_CODES = ["CL", "BL1", "DED", "BSA", "PD", "FL1", "ELC", "PPL", "SA", "PL"]
NATIONAL_CODES = ["WC", "EC"]
FOOTBALL_DATA_CODES = NATIONAL_CODES + CLUB_CODES
ALL_CODES = ["HNL"] + FOOTBALL_DATA_CODES
LIVE_STATUSES = {"LIVE", "IN_PLAY", "PAUSED", "EXTRA_TIME", "PENALTY_SHOOTOUT"}
FINISHED_STATUSES = {"FINISHED", "AWARDED"}
UPCOMING_STATUSES = {"TIMED", "SCHEDULED"}

# Official public SuperSport HNL pages.
HNL_RESULTS_URL = "https://hnl.hr/statistika/rezultati/"
HNL_STANDINGS_URL = "https://hnl.hr/statistika/ljestvica/"
HNL_TIMEZONE = ZoneInfo("Europe/Zagreb")
HNL_MIN_MATCHES = 10
HNL_EXPECTED_TEAMS = 10

HNL_TEAM_ALIASES = {
    "Dinamo": "Dinamo Zagreb",
    "GNK Dinamo": "Dinamo Zagreb",
    "Hajduk": "Hajduk Split",
    "HNK Hajduk": "Hajduk Split",
    "Gorica": "Gorica",
    "HNK Gorica": "Gorica",
    "Istra 1961": "Istra 1961",
    "Lokomotiva": "Lokomotiva Zagreb",
    "NK Lokomotiva": "Lokomotiva Zagreb",
    "Osijek": "Osijek",
    "NK Osijek": "Osijek",
    "Rijeka": "Rijeka",
    "HNK Rijeka": "Rijeka",
    "Rudeš": "Rudeš",
    "Rudes": "Rudeš",
    "Slaven Belupo": "Slaven Belupo",
    "Varaždin": "Varaždin",
    "Varazdin": "Varaždin",
    "Vukovar 1991": "Vukovar 1991",
}
HNL_SITE_TEAM_NAMES = sorted(HNL_TEAM_ALIASES.keys(), key=len, reverse=True)
HNL_TEAM_PATTERN = "(?:" + "|".join(re.escape(name) for name in HNL_SITE_TEAM_NAMES) + ")"

# Standings change far less often than live scores. Refresh only two stale
# football-data.org competitions per run so the updater stays safely inside
# the free-plan 10 requests/minute limit even when match details are needed.
STANDINGS_BATCH_SIZE = 2
STANDINGS_MAX_AGE = timedelta(hours=6)


def api_get(path: str, params: dict | None = None) -> dict:
    response = requests.get(f"{BASE_URL}{path}", headers=HEADERS, params=params, timeout=35)
    if response.status_code != 200:
        raise RuntimeError(f"football-data.org error {response.status_code}: {response.text[:500]}")
    return response.json()


def public_get(url: str) -> str:
    response = requests.get(url, headers=PUBLIC_HEADERS, timeout=35)
    if response.status_code != 200:
        raise RuntimeError(f"Public source error {response.status_code}: {url}")
    return response.text


def competition_code(match: dict) -> str:
    competition = match.get("competition") or {}
    if isinstance(competition, dict):
        return str(competition.get("code") or competition.get("name") or "").upper()
    return str(match.get("competitionName") or competition or "").upper()


def merge_matches(*collections: list[dict]) -> list[dict]:
    by_id: dict[int | str, dict] = {}
    for collection in collections:
        for match in collection or []:
            key = match.get("id") or (
                f"{match.get('utcDate') or match.get('date')}:"
                f"{match.get('homeTeam', {}).get('name')}:{match.get('awayTeam', {}).get('name')}"
            )
            by_id[key] = match
    return sorted(by_id.values(), key=lambda m: m.get("utcDate") or m.get("date") or "")


def should_fetch_details(match: dict, now: datetime) -> bool:
    # HNL is read from its own official public source and has no football-data.org ID.
    if competition_code(match) == "HNL":
        return False

    status = str(match.get("status") or "").upper()
    if status in LIVE_STATUSES:
        return True

    utc_date = match.get("utcDate")
    if not utc_date:
        return False
    try:
        kickoff = datetime.fromisoformat(utc_date.replace("Z", "+00:00"))
    except ValueError:
        return False

    if status in FINISHED_STATUSES and kickoff.date() == now.date():
        return True
    if status in UPCOMING_STATUSES and timedelta(hours=-1) <= kickoff - now <= timedelta(hours=4):
        return True
    return False


def enrich_with_match_details(matches: list[dict], now: datetime) -> list[dict]:
    enriched: list[dict] = []
    detailed_requests = 0

    for match in matches:
        item = match
        match_id = match.get("id")
        if isinstance(match_id, int) and should_fetch_details(match, now) and detailed_requests < 5:
            try:
                item = api_get(f"/matches/{match_id}")
                detailed_requests += 1
                time.sleep(1.2)
            except Exception as exc:
                print(f"Detail fetch failed for match {match_id}: {exc}")
        enriched.append(item)

    print(f"Detailed match requests: {detailed_requests}")
    return enriched


def without_timestamps(payload: dict) -> dict:
    cleaned = copy.deepcopy(payload)
    cleaned.pop("generatedAt", None)
    cleaned.pop("lastUpdate", None)
    return cleaned


def load_existing() -> dict | None:
    if not OUTPUT_FILE.exists():
        return None
    try:
        return json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def parse_utc(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def standings_age(entry: dict | None, now: datetime) -> timedelta:
    if not isinstance(entry, dict):
        return timedelta.max
    stamp = parse_utc(entry.get("updatedAt"))
    if stamp is None:
        return timedelta.max
    return now - stamp


def refresh_football_data_standings(existing: dict | None, now: datetime) -> dict:
    standings: dict = copy.deepcopy((existing or {}).get("standings") or {})

    ordered = sorted(
        FOOTBALL_DATA_CODES,
        key=lambda code: standings_age(standings.get(code), now),
        reverse=True,
    )
    candidates = [
        code for code in ordered
        if standings_age(standings.get(code), now) >= STANDINGS_MAX_AGE
    ]

    refreshed = 0
    for code in candidates[:STANDINGS_BATCH_SIZE]:
        try:
            payload = api_get(f"/competitions/{code}/standings")
            tables = payload.get("standings") or []
            if tables:
                standings[code] = {
                    "updatedAt": now.isoformat().replace("+00:00", "Z"),
                    "competition": payload.get("competition") or {},
                    "season": payload.get("season") or {},
                    "standings": tables,
                }
                refreshed += 1
                print(f"Standings refreshed: {code}")
            else:
                print(f"Standings unavailable/empty: {code}")
        except Exception as exc:
            # Cups may legitimately return 404. Keep any previous verified table.
            print(f"Standings fetch skipped for {code}: {exc}")

    print(f"Standings requests: {min(len(candidates), STANDINGS_BATCH_SIZE)}; refreshed: {refreshed}")
    return standings


def normalize_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", html_lib.unescape(value or "")).strip()


def canonical_hnl_team(value: str) -> str:
    clean = normalize_spaces(value)
    return HNL_TEAM_ALIASES.get(clean, clean)


def hnl_match_id(matchday: int, home: str, away: str, date_value: str) -> str:
    raw = unicodedata.normalize("NFKD", f"{home}-{away}").encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")
    return f"HNL-2026-27-{matchday:02d}-{date_value}-{slug}"


def parse_hnl_matches(page_html: str, now_utc: datetime) -> list[dict]:
    soup = BeautifulSoup(page_html, "html.parser")
    text = normalize_spaces(soup.get_text(" ", strip=True))

    # Example official-page text after HTML normalization:
    # Dinamo 2 : 0 Hajduk 09.05.2026. 16:00, Stadion Maksimir, Zagreb
    pattern = re.compile(
        rf"(?P<home>{HNL_TEAM_PATTERN})\s*"
        rf"(?:(?P<hg>\d+)\s*)?:\s*(?:(?P<ag>\d+)\s*)?"
        rf"(?P<away>{HNL_TEAM_PATTERN})\s+"
        rf"(?P<date>\d{{2}}\.\d{{2}}\.\d{{4}}\.)"
        rf"(?:\s+(?P<time>\d{{2}}:\d{{2}}))?\s*,\s*"
        rf"(?P<venue>.{{2,140}}?)"
        rf"(?=(?:\d{{2}}\.\d{{2}}\.\d{{4}}\.|\d{{1,2}}\.\s*kolo|Izvještaj|{HNL_TEAM_PATTERN}\s*(?:\d+\s*)?:|$))",
        re.IGNORECASE,
    )

    parsed: list[dict] = []
    seen: set[tuple[str, str, str]] = set()
    now_local = now_utc.astimezone(HNL_TIMEZONE)

    for found in pattern.finditer(text):
        home = canonical_hnl_team(found.group("home"))
        away = canonical_hnl_team(found.group("away"))
        date_raw = found.group("date")
        time_raw = found.group("time") or ""
        venue = normalize_spaces(found.group("venue")).strip(" ,-–")
        try:
            match_date = datetime.strptime(date_raw, "%d.%m.%Y.")
        except ValueError:
            continue

        date_key = match_date.strftime("%Y-%m-%d")
        key = (date_key, home, away)
        if key in seen:
            continue
        seen.add(key)

        hg = int(found.group("hg")) if found.group("hg") is not None else None
        ag = int(found.group("ag")) if found.group("ag") is not None else None
        has_score = hg is not None and ag is not None

        utc_date = None
        if time_raw:
            local_dt = datetime.strptime(f"{date_raw} {time_raw}", "%d.%m.%Y. %H:%M").replace(tzinfo=HNL_TIMEZONE)
            utc_date = local_dt.astimezone(timezone.utc)
            if has_score and local_dt - timedelta(minutes=20) <= now_local <= local_dt + timedelta(hours=3):
                status = "IN_PLAY"
            elif has_score and now_local > local_dt + timedelta(hours=3):
                status = "FINISHED"
            else:
                status = "SCHEDULED"
        else:
            local_dt = match_date.replace(tzinfo=HNL_TIMEZONE)
            # Without an official kickoff time we never invent a live window.
            # A published score is treated as a completed result.
            status = "FINISHED" if has_score else "SCHEDULED"

        parsed.append({
            "_localDate": date_key,
            "_localTime": time_raw,
            "id": "",
            "competition": {
                "id": 1001,
                "name": "HNL",
                "code": "HNL",
                "type": "LEAGUE",
            },
            "season": {
                "id": 202627,
                "startDate": "2026-08-01",
                "endDate": "2027-05-22",
                "currentMatchday": 0,
            },
            "utcDate": utc_date.isoformat().replace("+00:00", "Z") if utc_date else None,
            "date": None if utc_date else date_key,
            "status": status,
            "matchday": 0,
            "stage": "REGULAR_SEASON",
            "group": None,
            "homeTeam": {"name": home, "shortName": home},
            "awayTeam": {"name": away, "shortName": away},
            "score": {
                "winner": None,
                "duration": "REGULAR",
                "fullTime": {"home": hg, "away": ag},
                "halfTime": {"home": None, "away": None},
            },
            "venue": venue,
            "dataSource": "hnl.hr",
        })

    # The official page is ordered by rounds. Five matches form one HNL round.
    for index, match in enumerate(parsed):
        matchday = index // 5 + 1
        match["matchday"] = matchday
        match["season"]["currentMatchday"] = matchday
        match["id"] = hnl_match_id(matchday, match["homeTeam"]["name"], match["awayTeam"]["name"], match["_localDate"])
        match.pop("_localDate", None)
        match.pop("_localTime", None)

    return parsed


def parse_hnl_standings(page_html: str, now_utc: datetime) -> dict | None:
    soup = BeautifulSoup(page_html, "html.parser")
    text = normalize_spaces(soup.get_text(" ", strip=True))

    # Requires all official table values: played, wins, draws, losses,
    # goals for, goals against, goal difference and points.
    pattern = re.compile(
        rf"(?P<position>\d{{1,2}})\.?\s*(?P<team>{HNL_TEAM_PATTERN})\s+"
        rf"(?P<played>\d+)\s+(?P<wins>\d+)\s+(?P<draws>\d+)\s+(?P<losses>\d+)\s+"
        rf"(?P<gf>\d+)\s+(?P<ga>\d+)\s*(?P<gd>[+-]?\d+)\s+(?P<points>\d+)",
        re.IGNORECASE,
    )

    rows: list[dict] = []
    seen_positions: set[int] = set()
    for found in pattern.finditer(text):
        position = int(found.group("position"))
        if position in seen_positions or position < 1 or position > 20:
            continue
        seen_positions.add(position)
        team = canonical_hnl_team(found.group("team"))
        row = {
            "position": position,
            "team": {"id": 2000 + position, "name": team, "shortName": team, "tla": ""},
            "playedGames": int(found.group("played")),
            "form": None,
            "won": int(found.group("wins")),
            "draw": int(found.group("draws")),
            "lost": int(found.group("losses")),
            "points": int(found.group("points")),
            "goalsFor": int(found.group("gf")),
            "goalsAgainst": int(found.group("ga")),
            "goalDifference": int(found.group("gd")),
        }
        rows.append(row)
        if len(rows) == HNL_EXPECTED_TEAMS:
            break

    if len(rows) != HNL_EXPECTED_TEAMS:
        return None

    rows.sort(key=lambda row: row["position"])
    current_matchday = max((row["playedGames"] for row in rows), default=0)
    return {
        "updatedAt": now_utc.isoformat().replace("+00:00", "Z"),
        "competition": {"id": 1001, "name": "HNL", "code": "HNL", "type": "LEAGUE"},
        "season": {
            "id": 202627,
            "startDate": "2026-08-01",
            "endDate": "2027-05-22",
            "currentMatchday": current_matchday,
        },
        "standings": [{
            "stage": "REGULAR_SEASON",
            "type": "TOTAL",
            "group": None,
            "table": rows,
        }],
    }


def payload_without_updated_at(value):
    cleaned = copy.deepcopy(value)
    if isinstance(cleaned, dict):
        cleaned.pop("updatedAt", None)
    return cleaned


def existing_hnl_matches(existing: dict | None) -> list[dict]:
    if not existing:
        return []
    return [m for m in existing.get("matches") or [] if competition_code(m) == "HNL"]


def refresh_hnl(existing: dict | None, standings: dict, now: datetime) -> tuple[list[dict], dict, dict]:
    old_matches = existing_hnl_matches(existing)
    old_standings = standings.get("HNL")
    old_source = copy.deepcopy(((existing or {}).get("sources") or {}).get("HNL") or {})

    hnl_matches = old_matches
    hnl_standing_entry = old_standings
    source = old_source or {
        "name": "SuperSport HNL / HNS",
        "status": "waiting",
        "matchesUrl": HNL_RESULTS_URL,
        "standingsUrl": HNL_STANDINGS_URL,
    }

    matches_ok = False
    standings_ok = False
    matches_changed = False
    standings_changed = False

    try:
        parsed_matches = parse_hnl_matches(public_get(HNL_RESULTS_URL), now)
        if len(parsed_matches) >= HNL_MIN_MATCHES:
            matches_changed = parsed_matches != old_matches
            hnl_matches = parsed_matches if matches_changed or not old_matches else old_matches
            matches_ok = True
            print(f"HNL official matches parsed: {len(parsed_matches)}")
        else:
            print(f"HNL parser returned only {len(parsed_matches)} matches; keeping previous verified data")
    except Exception as exc:
        print(f"HNL matches refresh failed; keeping previous data: {exc}")

    try:
        parsed_standings = parse_hnl_standings(public_get(HNL_STANDINGS_URL), now)
        if parsed_standings is not None:
            standings_changed = not old_standings or payload_without_updated_at(old_standings) != payload_without_updated_at(parsed_standings)
            hnl_standing_entry = parsed_standings if standings_changed else old_standings
            standings_ok = True
            print("HNL official standings parsed: 10 teams")
        else:
            print("HNL standings parser validation failed; keeping previous verified table")
    except Exception as exc:
        print(f"HNL standings refresh failed; keeping previous table: {exc}")

    if hnl_standing_entry is not None:
        standings["HNL"] = hnl_standing_entry

    if matches_ok or standings_ok or hnl_matches or hnl_standing_entry:
        source.update({
            "name": "SuperSport HNL / HNS",
            "status": "connected",
            "matchesUrl": HNL_RESULTS_URL,
            "standingsUrl": HNL_STANDINGS_URL,
        })
        if matches_changed or standings_changed or not source.get("lastSuccessfulUpdate"):
            source["lastSuccessfulUpdate"] = now.isoformat().replace("+00:00", "Z")
    else:
        source["status"] = "waiting"

    return hnl_matches, standings, source


def main() -> None:
    now = datetime.now(timezone.utc)
    existing = load_existing()

    # Preserve the complete World Cup list so group tables and knockout history
    # remain available throughout the tournament.
    world_cup = api_get("/competitions/WC/matches").get("matches", [])

    # Other supported competitions are kept focused around the current period.
    date_from = (now - timedelta(days=14)).date().isoformat()
    date_to = (now + timedelta(days=60)).date().isoformat()
    other_codes = ",".join(code for code in FOOTBALL_DATA_CODES if code != "WC")
    nearby = api_get(
        "/matches",
        params={"competitions": other_codes, "dateFrom": date_from, "dateTo": date_to},
    ).get("matches", [])

    standings = refresh_football_data_standings(existing, now)
    hnl_matches, standings, hnl_source = refresh_hnl(existing, standings, now)

    matches = merge_matches(world_cup, nearby, hnl_matches)
    matches = enrich_with_match_details(matches, now)

    sources = copy.deepcopy((existing or {}).get("sources") or {})
    sources["football-data.org"] = {
        "name": "football-data.org",
        "status": "connected",
        "competitionCodes": FOOTBALL_DATA_CODES,
    }
    sources["HNL"] = hnl_source

    output = {
        "source": "Football Fun multi-source data service",
        "generatedAt": now.strftime("%Y-%m-%d %H:%M UTC"),
        "lastUpdate": now.strftime("%Y-%m-%d %H:%M UTC"),
        "competitionCodes": ALL_CODES,
        "sources": sources,
        "matches": matches,
        "live": [],
        "finished": [],
        "upcoming": [],
        "standings": standings,
    }

    for match in matches:
        status = str(match.get("status") or "").upper()
        if status in LIVE_STATUSES:
            output["live"].append(match)
        elif status in FINISHED_STATUSES:
            output["finished"].append(match)
        elif status in UPCOMING_STATUSES:
            output["upcoming"].append(match)

    if existing is not None and without_timestamps(existing) == without_timestamps(output):
        print("No football data changes; live-results.json left unchanged")
        return

    OUTPUT_FILE.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print("live-results.json updated")
    print("Matches:", len(matches))
    print("HNL matches:", len(hnl_matches))
    print("Live:", len(output["live"]))
    print("Finished:", len(output["finished"]))
    print("Upcoming:", len(output["upcoming"]))
    print("Standings available:", len(standings))


if __name__ == "__main__":
    main()
